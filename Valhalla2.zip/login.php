<?php require_once('config/config.php'); ?>

<?php

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Login | Valhalla 2.0</title>
</head>
<body>

</body>
</html>