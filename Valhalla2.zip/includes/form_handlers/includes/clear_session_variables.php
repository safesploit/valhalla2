<?php
	$_SESSION['reg_fname'] = "";
	$_SESSION['reg_lname'] = "";
	$_SESSION['reg_em'] = "";
	$_SESSION['reg_em2'] = "";
	$_SESSION['reg_password'] = "";
	$_SESSION['reg_password2'] = "";
?>