<?php
	$rand = rand(1, 2); //PRNG between 1 and 2

	if ($rand = 1)
	{
		$profile_pic = "assets/images/profile_pics/default/default_pic.jpg";
	}
	else if ($rand = 2)
	{
		$profile_pic = "assets/images/profile_pics/default/default_pic.jpg";
	}
?>