$(document).ready(function() 
{

	setInterval(function() 
	{
    	//call $.ajax here
	}, 5000); //5 seconds

});